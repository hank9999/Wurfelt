package me.misoryan.utils.libs;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class CommandDelay {
    public static Map<String, Number> Delay;
    public CommandDelay() {
        Delay = new HashMap<String, Number>();
    }
}
