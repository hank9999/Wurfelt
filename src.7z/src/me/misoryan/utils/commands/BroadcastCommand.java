package me.misoryan.utils.commands;

import me.misoryan.utils.libs.Lib;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class BroadcastCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {
        if (command.getName().equalsIgnoreCase("bc") || command.getName().equalsIgnoreCase("broadcast")) {
            if (!commandSender.hasPermission("admin")) {
                commandSender.sendMessage(Lib.getCurrentText("&cPermission Denied."));
                return true;
            }
            String text = Lib.getCurrentText(Lib.getCurrentArgsFormat(strings,0));
            String prefix = Lib.getCurrentText("&8[&3Alert&8] &7");
            if (text.startsWith(Lib.getCurrentText("&u"))) {
                prefix = "";
            }
            Bukkit.broadcastMessage(prefix + text);
        }
        return true;
    }
}
