package me.misoryan.utils.commands;

import me.misoryan.utils.libs.Lib;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.Objects;

import static org.bukkit.Bukkit.getEntity;
import static org.bukkit.Bukkit.getServer;

public class TpacceptCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {
        if (command.getName().equalsIgnoreCase("tpaccept") || command.getName().equalsIgnoreCase("tpyes")) {
        if (TpaCommand.TeleportReceiver.get(Bukkit.getPlayer(commandSender.getName())) == null) {
            commandSender.sendMessage(Lib.getCurrentText("&c没有待处理的传送请求..."));
            return true;
        }
            Bukkit.getPlayer(TpaCommand.TeleportReceiver.get(Bukkit.getPlayer(commandSender.getName()))).teleport(getEntity(Bukkit.getPlayer(commandSender.getName()).getUniqueId()));
            TpaCommand.TeleportCommandDelay.put(Bukkit.getPlayer(TpaCommand.TeleportReceiver.get(Bukkit.getPlayer(commandSender.getName()))),null);
            TpaCommand.TeleportReceiver.put(Bukkit.getPlayer(commandSender.getName()),null);
        }
        return true;
    }
}
