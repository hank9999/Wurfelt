package me.misoryan.utils.commands;

import me.misoryan.utils.Main;
import me.misoryan.utils.libs.Lib;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FreezeCommand implements CommandExecutor {

    public static Map<String, String> freezeing;

    public FreezeCommand() {
        freezeing = new HashMap<String, String>();
    }
    @Override
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (command.getName().equalsIgnoreCase("freeze")) {
            if (!sender.hasPermission("NMSL.ss")) {
                sender.sendMessage(ChatColor.RED + "Permission denied.");
                return true;
            }
            if (args.length != 1) {
                sender.sendMessage(ChatColor.RED + "Usage: /freeze ID");
                return true;
            }
            if (Bukkit.getPlayerExact(args[0]) == null) {
                sender.sendMessage(ChatColor.RED + "This player is offline.");
            }
            else if (freezeing.get(args[0]) == null) {
                freezeing.put(args[0], sender.getName());
                final Inventory inventory = Bukkit.createInventory(null, 9, Lib.getCurrentText(Main.ins.getConfig().getString("freeze.title")));
                final ItemStack itemStack = new ItemStack(Material.YELLOW_DYE);
                final ItemMeta itemMeta = itemStack.getItemMeta();
                int i = 0;
                for (final String l : Main.ins.getConfig().getStringList("freeze.lore")) {
                    ++i;
                }
                final ArrayList<String> lore = new ArrayList<String>();
                i = 0;
                for (String j : Main.ins.getConfig().getStringList("freeze.lore")) {
                    j = j.replace("&", "§");
                    j = j.replace("[OPERATOR]", freezeing.get(args[0]));
                    lore.add(j);
                    ++i;
                }
                itemMeta.setLore(lore);
                itemMeta.setDisplayName(Main.ins.getConfig().getString("freeze.title").replaceAll("&", "§"));
                itemStack.setItemMeta(itemMeta);
                inventory.setItem(4, itemStack);
                Bukkit.getPlayerExact(args[0]).openInventory(inventory);
                Bukkit.getPlayerExact(args[0]).sendMessage(ChatColor.RED + "You have been frozen by a staff.");
                sender.sendMessage(ChatColor.GOLD + "You froze " + ChatColor.YELLOW + args[0] + " .");
            }
            else {
                freezeing.remove(args[0]);
                Bukkit.getPlayerExact(args[0]).closeInventory();
                Bukkit.getPlayerExact(args[0]).sendMessage(ChatColor.GREEN + "A staff unfroze you.");
                sender.sendMessage(ChatColor.GREEN + "You unfroze " + args[0] + " .");
            }
        }
        return true;
    }
}
