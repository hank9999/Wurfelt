package me.misoryan.utils.listener;

import me.misoryan.utils.Main;
import me.misoryan.utils.commands.FreezeCommand;
import me.misoryan.utils.libs.Lib;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;

public class FreezeListener implements Listener {
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(final EntityDamageByEntityEvent e) {
        if (FreezeCommand.freezeing.get(e.getEntity().getName()) != null) {
            e.setCancelled(true);
        }
        if (FreezeCommand.freezeing.get(e.getDamager().getName()) != null) {
            e.setCancelled(true);
            Bukkit.broadcastMessage(ChatColor.RED + "Player " + e.getDamager().getName() + "is trying to damage others while freezeing!");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(final InventoryClickEvent e) {
        if (FreezeCommand.freezeing.get(e.getWhoClicked().getName()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClose(final InventoryCloseEvent e) {
        if (FreezeCommand.freezeing.get(e.getPlayer().getName()) != null) {
            if (Bukkit.getPlayerExact(e.getPlayer().getName()) == null) {
                return;
            }
            new BukkitRunnable() {
                @Override
                public void run() {
                    final Inventory inventory = Bukkit.createInventory(null, 9, Lib.getCurrentText(Main.ins.getConfig().getString("freeze.title")));
                    final ItemStack itemStack = new ItemStack(Material.YELLOW_DYE);
                    final ItemMeta itemMeta = itemStack.getItemMeta();
                    int i = 0;
                    for (final String l : Main.ins.getConfig().getStringList("freeze.lore")) {
                        ++i;
                    }
                    final ArrayList<String> lore = new ArrayList<String>();
                    i = 0;
                    for (String j : Main.ins.getConfig().getStringList("freeze.lore")) {
                        j = j.replace("&", "§");
                        j = j.replace("[OPERATOR]", FreezeCommand.freezeing.get(e.getPlayer().getName()));
                        lore.add(j);
                        ++i;
                    }
                    itemMeta.setLore(lore);
                    itemMeta.setDisplayName(Main.ins.getConfig().getString("freeze.title").replaceAll("&", "§"));
                    itemStack.setItemMeta(itemMeta);
                    inventory.setItem(4, itemStack);
                    e.getPlayer().openInventory(inventory);
                }
            }.runTaskLater(Main.ins,3L);
        }
    }

    @EventHandler
    public void onDisconnect(final PlayerQuitEvent e) {
        if (FreezeCommand.freezeing.get(e.getPlayer().getName()) != null) {
            for (final String x : Main.ins.getConfig().getStringList("freeze.disconnect-message")) {
                Bukkit.broadcastMessage(x.replaceAll("&", "§"));
            }
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Main.ins.getConfig().getString("freeze.command"));
            FreezeCommand.freezeing.remove(e.getPlayer().getName());
        }
    }
}
